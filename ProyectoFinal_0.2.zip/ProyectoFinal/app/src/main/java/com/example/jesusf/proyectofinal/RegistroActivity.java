package com.example.jesusf.proyectofinal;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;
import android.view.inputmethod.InputMethodManager;

public class RegistroActivity extends AppCompatActivity {

    private EditText registerUserName = null;
    private EditText registerMail = null;
    private EditText registerPass = null;
    private EditText registerPass2 = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        getSupportActionBar().hide();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_registro_activity);

        registerUserName    =   findViewById(R.id.editText_user);
        registerMail        =   findViewById(R.id.editText_mail);
        registerPass        =   findViewById(R.id.editText_pass);
        registerPass2       =   findViewById(R.id.editText_pass2);
    }

    public void clickOnAceptarRegistro(View view) {

        registerUserName.getText().toString();
        registerMail.getText().toString();
        registerPass.getText().toString();
        registerPass2.getText().toString();

        //Oculta el teclado en pantalla
        InputMethodManager imm = (InputMethodManager) getSystemService(this.INPUT_METHOD_SERVICE);
        imm.toggleSoftInput(InputMethodManager.HIDE_IMPLICIT_ONLY, 0);

        //Condiciones para registro
        if (registerPass != registerPass2){
            String errorPass    =   "Las contraseñas no coinciden";
            registerPass.setText(""); registerPass2.setText("");
            Toast.makeText(this, errorPass, Toast.LENGTH_SHORT).show();
        }

    }
}
