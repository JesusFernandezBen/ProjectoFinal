package com.example.jesusf.proyectofinal;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.InputMethodManager;

public class IniciarActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        getSupportActionBar().hide();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_iniciar_activity);
        
    }



    public void clickOnInicio(View view) {
        //Oculta el teclado en pantalla
        InputMethodManager imm = (InputMethodManager) getSystemService(this.INPUT_METHOD_SERVICE);
        imm.toggleSoftInput(InputMethodManager.HIDE_IMPLICIT_ONLY, 0);

        Intent intent = new Intent(this, LoginActivity.class);
        startActivity(intent);
        }

    public void clickOnRegistro(View view) {
        //Oculta el teclado en pantalla
        InputMethodManager imm = (InputMethodManager) getSystemService(this.INPUT_METHOD_SERVICE);
        imm.toggleSoftInput(InputMethodManager.HIDE_IMPLICIT_ONLY, 0);

        //Inicia actividad RegistroActivity
        Intent intent = new Intent(this, RegistroActivity.class);
        startActivity(intent);
    }
}
