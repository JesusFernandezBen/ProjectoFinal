package com.example.jesusf.proyectofinal;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class LoginActivity extends AppCompatActivity {


    private EditText nombreUsuario, userPass;
    private Button iniciarSesion;

    FirebaseAuth.AuthStateListener mAuthListener;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        getSupportActionBar().hide();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_login_activity);

        nombreUsuario = findViewById(R.id.txtuser);
        userPass = findViewById(R.id.txtpass);

        iniciarSesion = findViewById(R.id.button_inicio);

        mAuthListener = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                FirebaseUser user = firebaseAuth.getCurrentUser();
                if (user != null) {
                    System.out.println("Sesión iniciada con email: " + user.getEmail());
                } else {
                    System.out.println("Sesión cerrada");
                }
            }
        };

    }


    public void clickOnLogin (View v){
        //Oculta el teclado en pantalla
        InputMethodManager imm = (InputMethodManager) getSystemService(this.INPUT_METHOD_SERVICE);
        imm.toggleSoftInput(InputMethodManager.HIDE_IMPLICIT_ONLY, 0);

        // Recoge los valores de "usuario" y "contraseña" y los pasa al metodo validar.
        validar(nombreUsuario.getText().toString(),userPass.getText().toString());
    }

    private void validar (String stringUsuario, String stringPass){
        // Comprueba temporalmente si dos strings son iguales, si lo son, inicia una nueva actividad, si no muestra el nombre y la contraseña introducidos para comprobaciones.

        if ((stringUsuario.equals("Admin"))&&(stringPass.equals("Admin"))){
            Intent intent = new Intent(this, MainGame.class);
            startActivity(intent);
        }
        else  {
            System.out.println(nombreUsuario);
            System.out.println(userPass);
        }
    }


    public void iniciarSesion(View v){
        String email = nombreUsuario.getText().toString();
        String pass = userPass.getText().toString();

        FirebaseAuth.getInstance().signInWithEmailAndPassword(email, pass).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if(task.isSuccessful()){
                    System.out.println("La sesión se ha iniciado correctamente");
                }else{
                    System.out.println("La sesión no se ha podido iniciar");
                }
            }
        });

    }
}
