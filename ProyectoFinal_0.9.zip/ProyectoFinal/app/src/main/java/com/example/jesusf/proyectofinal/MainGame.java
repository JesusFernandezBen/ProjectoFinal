package com.example.jesusf.proyectofinal;

import android.content.DialogInterface;
import android.graphics.Color;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class MainGame extends AppCompatActivity implements View.OnClickListener {

    public Button buttonViaje, buttonSalir, buttonSalir2, buttonDerecha, buttonIzquierda;
    public TextView textDinamico, textInicio;
    public ImageView imagentitulo, imageViewDinamica;

    // He añadido un par de vectores que almacenarán las imagenes que usarán los botones de izquierda y derecha.
    int[] listaImgA = new int[]{
            R.drawable.drawable1a, R.drawable.drawable2a, R.drawable.drawable3a, R.drawable.drawable4a, R.drawable.drawable_final
    };
    int[] listaImgB = new int[]{
            R.drawable.drawable1b, R.drawable.drawable2b, R.drawable.drawable3b, R.drawable.drawable4b, R.drawable.drawable_final
    };

    //estos son los contadores que usarán los botones de izquierda y derecha.
    int contb = 0;
    int conta = 0;


    /**
     * @param savedInstanceState
     * */

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_main_game);

        //Encadenamiento de variables a sus ID correspondientes
        buttonViaje = findViewById(R.id.buttonComenzarViaje);
        buttonSalir = findViewById(R.id.buttonSalir);
        buttonSalir2 = findViewById(R.id.buttonSalir2);
        buttonDerecha = findViewById(R.id.buttonR);
        buttonIzquierda = findViewById(R.id.buttonL);
        textDinamico = findViewById(R.id.textViewDinamico);
        textInicio = findViewById(R.id.textViewInicial);
        imagentitulo = findViewById(R.id.imageViewTitulo);
        imageViewDinamica = findViewById(R.id.imageViewDinamico);

        //Establece la invisibilidad de algunos elementos al crear la actividad
        buttonDerecha.setVisibility(View.GONE);
        buttonIzquierda.setVisibility(View.GONE);
        textDinamico.setVisibility(View.GONE);
        buttonSalir2.setVisibility(View.GONE);

        //Se le introduce cadena de textos a los textViews correspondientes
        textInicio.setText("Otra vez la carretera... \n ¿A donde me llevará esta vez?");

        //se añade los listener a los botones.
        buttonViaje.setOnClickListener(this);
        buttonSalir.setOnClickListener(this);
        buttonSalir2.setOnClickListener(this);
        buttonIzquierda.setOnClickListener(this);
        buttonDerecha.setOnClickListener(this);
    }

    /**
     * @param v
     * */

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.buttonComenzarViaje:
                //Oculta los siguientes botones
                buttonViaje.setVisibility(View.GONE);
                buttonSalir.setVisibility(View.GONE);
                buttonSalir2.setVisibility(View.GONE);
                textInicio.setVisibility(View.GONE);

                //Muestra los siguientes botones
                buttonDerecha.setVisibility(View.VISIBLE);
                buttonIzquierda.setVisibility(View.VISIBLE);

                //Oculta la imagen inicinal
                imagentitulo.setVisibility(View.GONE);

                //Establece la imagen inicial.
                imageViewDinamica.setImageResource(R.drawable.drawable_inicio);

                //Establece y muestra el texto dinamico inicial
                textDinamico.setText("1 Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.");
                textDinamico.setVisibility(View.VISIBLE);
                break;

            case R.id.buttonSalir:
                textInicio.setVisibility(View.GONE);
                AlertDialog.Builder builder = new AlertDialog.Builder(this);
                builder.setTitle("¿quizás sea mejor despertar?...");
                builder.setPositiveButton("Si", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                        int pid = android.os.Process.myPid();
                        android.os.Process.killProcess(pid);
                        finish();
                    }
                });
                builder.setNegativeButton("No, quiero seguir soñando.", new DialogInterface.OnClickListener() {
                    @
                            Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
                AlertDialog alert = builder.create();
                alert.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
                alert.show();
                alert.getButton(AlertDialog.BUTTON_NEGATIVE).setTextColor(Color.WHITE);
                alert.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(Color.WHITE);
                break;

                case R.id.buttonR:
                if (conta == 0) {
                    imageViewDinamica.setImageResource(listaImgA[conta]);
                    conta = conta + 1;
                    contb = contb + 1;
                } else {
                    if (conta == 4) {
                        imageViewDinamica.setImageResource(listaImgA[conta]);

                        //cambia la cadena de texto de textoInicio y la muestra
                        textInicio.setText("has llegado al final, por ahora...");
                        textInicio.setVisibility(View.VISIBLE);

                        //muestra el titulo  y establece la visibilidad de algunos botones
                        imagentitulo.setVisibility(View.VISIBLE);
                        textDinamico.setVisibility(View.GONE);
                        buttonIzquierda.setVisibility(View.GONE);
                        buttonDerecha.setVisibility(View.GONE);
                        buttonSalir2.setVisibility(View.VISIBLE);

                     } else {
                        imageViewDinamica.setImageResource(listaImgA[conta]);
                        conta = conta + 1;
                        contb = contb + 1;
                    }
                }
                break;

            case R.id.buttonL:
                if (conta == 0) {
                    imageViewDinamica.setImageResource(listaImgB[contb]);
                    conta = conta + 1;
                    contb = contb + 1;
                } else {
                    if (conta == 4) {
                        imageViewDinamica.setImageResource(listaImgB[contb]);

                        //cambia la cadena de texto de textoInicio y la muestra
                        textInicio.setText("has llegado al final, por ahora...");
                        textInicio.setVisibility(View.VISIBLE);

                        //muestra el titulo  y establece la visibilidad de algunos botones
                        imagentitulo.setVisibility(View.VISIBLE);
                        textDinamico.setVisibility(View.GONE);
                        buttonIzquierda.setVisibility(View.GONE);
                        buttonDerecha.setVisibility(View.GONE);
                        buttonSalir2.setVisibility(View.VISIBLE);

                    } else {
                        imageViewDinamica.setImageResource(listaImgB[contb]);
                        conta = conta + 1;
                        contb = contb + 1;
                    }
                }
                break;

            case R.id.buttonSalir2:

                textInicio.setVisibility(View.GONE);

                AlertDialog.Builder builder2 = new AlertDialog.Builder(this);

                builder2.setPositiveButton("Despertar", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                        int pid = android.os.Process.myPid();
                        android.os.Process.killProcess(pid);
                        finish();
                    }
                });

                AlertDialog alert2 = builder2.create();
                alert2.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
                alert2.show();
                alert2.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(Color.WHITE);

                break;
        }
    }
}