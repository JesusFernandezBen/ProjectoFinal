package com.example.jesusf.proyectofinal;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.view.inputmethod.InputMethodManager;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.ProviderQueryResult;

import java.sql.SQLOutput;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegistroActivity extends AppCompatActivity implements View.OnClickListener {

    private static final String EMAIL_PATTERN = "^[a-zA-Z0-9#_~!$&'()*+,;=:.\"(),:;<>@\\[\\]\\\\]+@[a-zA-Z0-9-]+(\\.[a-zA-Z0-9-]+)*$";
    private Pattern pattern = Pattern.compile(EMAIL_PATTERN);
    private Matcher matcher;

    FirebaseAuth auth;
    EditText registerMail,
            registerPass,
            registerPass2;
    Button buttonRegister;

    FirebaseAuth.AuthStateListener mAuthListener;


    /**
     * @param savedInstanceState
     * */

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        //getSupportActionBar().hide();

        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_registro_activity);
        auth = FirebaseAuth.getInstance();

        registerMail = findViewById(R.id.editText_mail);
        registerPass = findViewById(R.id.editText_pass);
        registerPass2 = findViewById(R.id.editText_pass2);

        buttonRegister = findViewById(R.id.button_registro);
        buttonRegister.setOnClickListener(this);

        mAuthListener = new FirebaseAuth.AuthStateListener() {@Override
        public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
            FirebaseUser user = firebaseAuth.getCurrentUser();
            if (user != null) {

                System.out.println("Sesión iniciada con email: " + user.getEmail());
            } else {
                System.out.println("Sesión cerrada");
            }
        }
        };

        muestraEmail();
    }

    /**
     * @param v
     * */

    //Realiza comprobaciones al pulsar el boton de registro, y pasa datos al metodo "registrar"
    @Override
    public void onClick(View v) {

        String email = registerMail.getText().toString();
        String pass = registerPass.getText().toString();
        String pass2 = registerPass2.getText().toString();

        //Oculta el teclado en pantalla
        InputMethodManager imm = (InputMethodManager) getSystemService(this.INPUT_METHOD_SERVICE);
        imm.toggleSoftInput(InputMethodManager.HIDE_IMPLICIT_ONLY, 0);

        //Comprueba s las contraseñas coinciden.
        if (pass.equals(pass2)) {

            //Comprueba que el email tenga un formato valido antes de continuar con su registro.
            validaEmail(email);

            if (matcher.matches() == true) {

                System.out.println(matcher.matches());

                //toast
                Context context = getApplicationContext();
                CharSequence text = "Registrando...";
                int duration = Toast.LENGTH_SHORT;

                Toast toast = Toast.makeText(context, text, duration);
                toast.show();

                // recoge las variables de mail y contraseña y las pasa al metodo registrar
                registrar(email, pass);
            } else {

                registerMail.setText("");

                //toast
                Context context = getApplicationContext();
                CharSequence text = "El Email no tiene un formato correcto";
                int duration = Toast.LENGTH_SHORT;

                Toast toast = Toast.makeText(context, text, duration);
                toast.show();

                //console
                System.out.println("El email no tiene un formato correcto");
            }

        } else {

            //borra las contraseñas
            registerPass.setText("");
            registerPass2.setText("");

            //toast
            Context context = getApplicationContext();
            CharSequence text = "Las contraseñas no coinciden.";
            int duration = Toast.LENGTH_SHORT;

            Toast toast = Toast.makeText(context, text, duration);
            toast.show();

        }
    }

    /**
     * @param email
     * */

    //Comprueba que los emails tienen el formato correcto.
    public boolean validaEmail(String email) {
        matcher = pattern.matcher(email);
        return matcher.matches();
    }

    //registra el usuario en firebase si es posible.
    private void registrar(String email, String pass) {
        FirebaseAuth.getInstance().createUserWithEmailAndPassword(email, pass).addOnCompleteListener(new OnCompleteListener < AuthResult > () {@Override
        public void onComplete(@NonNull Task < AuthResult > task) {

            if (task.isSuccessful()) {

                //toast
                Context context = getApplicationContext();
                CharSequence text = "Usuario creado correctamente";
                int duration = Toast.LENGTH_SHORT;
                Toast toast = Toast.makeText(context, text, duration);
                toast.show();

                //console
                System.out.println("Usuario creado correctamente");

            } else {
                //toast
                Context context = getApplicationContext();
                CharSequence text = "El usuario no se ha podido crear";
                int duration = Toast.LENGTH_SHORT;
                Toast toast = Toast.makeText(context, text, duration);
                toast.show();

                //console
                System.out.println("El usuario no se ha podido crear");
            }
        }
        });
    }


    //Muestra el email actual en la esquina superior derecha
    public void muestraEmail() {
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        TextView MuestraEmail = (TextView) findViewById(R.id.MuestraEmail);
        View botonLogout = findViewById(R.id.buttonLogout);

        if (user == null){
            botonLogout.setVisibility(View.GONE);
            MuestraEmail.setText("");
        } else{
            MuestraEmail.setText(user.getEmail());
            botonLogout.setVisibility(View.VISIBLE);
        }
    }

    /**
     * @param view
     * */

    //Desconecta el usuario actual y lleva a la actividad de LoginActivity.
    public void logout(View view) {
        System.out.println("Ha entrado en logout");
        FirebaseAuth.getInstance().signOut();

        //actualiza el email en la esquina derecha, queda en blanco si el usuario es = null.
        muestraEmail();

        //Inicia Actividad LoginActivity
        Intent intent = new Intent(getApplicationContext(), LoginActivity.class);
        startActivity(intent);
    }

    //metodos de ciclo de la aplicación.
    @Override
    protected void onStart() {
        super.onStart();
        FirebaseAuth.getInstance().addAuthStateListener(mAuthListener);
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (mAuthListener != null) {
            FirebaseAuth.getInstance().removeAuthStateListener(mAuthListener);

        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mAuthListener != null) {
            FirebaseAuth.getInstance().removeAuthStateListener(mAuthListener);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (mAuthListener != null) {
            FirebaseAuth.getInstance().removeAuthStateListener(mAuthListener);
        }
        muestraEmail();
    }
}