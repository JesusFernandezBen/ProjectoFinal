package com.example.jesusf.proyectofinal;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class MainGame extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        getSupportActionBar().hide();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_main_game);

    }
}
