package com.example.jesusf.proyectofinal;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class IniciarActivity extends AppCompatActivity {

    FirebaseAuth.AuthStateListener mAuthListener;
    FirebaseUser user;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        //getSupportActionBar().hide();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_iniciar_activity);

        user = FirebaseAuth.getInstance().getCurrentUser();

        mAuthListener = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {}
        };
    }

    // TODO borrar console, arreglar comentarios.

    public void clickOnInicio(View view) {
        if (user != null) {
            System.out.println("Sesión iniciada con email: " + user.getEmail());
            //Inicia Actividad MainGame
            Intent intent = new Intent(getApplicationContext(), MainGame.class);
            startActivity(intent);

        } else {

            System.out.println("No hay usuario logeado, inicia login");
            //Inicia Actividad LoginActivity
            Intent intent = new Intent(getApplicationContext(), LoginActivity.class);
            startActivity(intent);
        }

        //muestra el usuario logeado actualmente en la esquina superior derecha.
        muestraEmail();
    }

    public void clickOnRegistro(View view) {
        //Inicia actividad RegistroActivity
        Intent intent = new Intent(this, RegistroActivity.class);
        startActivity(intent);
    }

    //Muestra el email actual en la esquina superior derecha
    public void muestraEmail() {
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        TextView MuestraEmail = (TextView) findViewById(R.id.MuestraEmail);
        View botonLogout = findViewById(R.id.buttonLogout);

        if (user == null){
            botonLogout.setVisibility(View.GONE);
            MuestraEmail.setText("");
        } else{
            MuestraEmail.setText(user.getEmail());
            botonLogout.setVisibility(View.VISIBLE);
        }
    }

    //Desconecta el usuario actual y lleva a la actividad de LoginActivity.
    public void logout(View view) {

        //console
        System.out.println("Ha entrado en logout");

        FirebaseAuth.getInstance().signOut();
        //actualiza el email en la esquina derecha, queda en blanco si el usuario es = null.
        muestraEmail();

        //Inicia Actividad LoginActivity
        Intent intent = new Intent(getApplicationContext(), LoginActivity.class);
        startActivity(intent);
    }

    @Override
    protected void onStart() {
        super.onStart();
        FirebaseAuth.getInstance().addAuthStateListener(mAuthListener);
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (mAuthListener != null) {
            FirebaseAuth.getInstance().removeAuthStateListener(mAuthListener);

        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mAuthListener != null) {
            FirebaseAuth.getInstance().removeAuthStateListener(mAuthListener);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (mAuthListener != null) {
            FirebaseAuth.getInstance().removeAuthStateListener(mAuthListener);
        }
        muestraEmail();
    }
}