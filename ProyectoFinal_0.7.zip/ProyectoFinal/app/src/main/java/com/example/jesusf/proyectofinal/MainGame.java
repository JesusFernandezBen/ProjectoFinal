package com.example.jesusf.proyectofinal;

import android.content.DialogInterface;
import android.graphics.Color;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class MainGame extends AppCompatActivity implements View.OnClickListener {

    public Button       buttonViaje, buttonSalir, buttonDerecha, buttonIzquierda;
    public TextView     textDinamico, textInicio;
    public ImageView    ImagenTitulo, imageViewDinamica;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_main_game);

        //Encadenamiento de variables a sus ID correspondientes
        buttonViaje         =   findViewById(R.id.buttonComenzarViaje);
        buttonSalir         =   findViewById(R.id.buttonSalir);
        buttonDerecha       =   findViewById(R.id.buttonR);
        buttonIzquierda     =   findViewById(R.id.buttonL);

        textDinamico        =   findViewById(R.id.textViewDinamico);
        textInicio          =   findViewById(R.id.textViewInicial);

        ImagenTitulo        =   findViewById(R.id.imageViewTitulo);
        imageViewDinamica   =   findViewById(R.id.imageViewDinamico);

        //Establece la invisibilidad de algunos elementos al crear la actividad
        buttonDerecha.setVisibility(View.GONE);
        buttonIzquierda.setVisibility(View.GONE);

        textDinamico.setVisibility(View.GONE);

        //Se le introduce cadena de textos a los textViews correspondientes
        textInicio.setText("Otra vez la carretera... \n ¿A donde me llevará esta vez?");

        //se añade el listener a los botones.
        buttonViaje.setOnClickListener(this);
        buttonSalir.setOnClickListener(this);
        buttonIzquierda.setOnClickListener(this);
        buttonDerecha.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){

            case R.id.buttonComenzarViaje:
                //Oculta los siguientes botones
                buttonViaje.setVisibility(View.GONE);
                buttonSalir.setVisibility(View.GONE);
                textInicio.setVisibility(View.GONE);

                //Muestra los siguientes botones
                buttonDerecha.setVisibility(View.VISIBLE);
                buttonIzquierda.setVisibility(View.VISIBLE);
                break;

            case R.id.buttonSalir:
                textInicio.setVisibility(View.GONE);

                AlertDialog.Builder builder = new AlertDialog.Builder(this);

                builder.setTitle("¿quizás sea mejor despertar?...");

                builder.setPositiveButton("Si", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                        int pid = android.os.Process.myPid();
                        android.os.Process.killProcess(pid);
                    }
                });

                builder.setNegativeButton("No, quiero seguir soñando.", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
                AlertDialog alert = builder.create();
                alert.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
                alert.show();
                alert.getButton(AlertDialog.BUTTON_NEGATIVE).setTextColor(Color.WHITE);
                alert.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(Color.WHITE);
                break;

            case R.id.buttonR:
                break;
            case R.id.buttonL:
                break;
        }
    }
}
