package com.example.jesusf.proyectofinal;

import android.content.Context;
import android.graphics.Color;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;
import android.view.inputmethod.InputMethodManager;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

import java.sql.SQLOutput;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegistroActivity extends AppCompatActivity {

    private EditText registerMail = null;
    private EditText registerPass = null;
    private EditText registerPass2 = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        getSupportActionBar().hide();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_registro_activity);

        registerMail        =   findViewById(R.id.editText_mail);
        registerPass        =   findViewById(R.id.editText_pass);
        registerPass2       =   findViewById(R.id.editText_pass2);
    }

    public void clickOnAceptarRegistro(View view) {

        registerMail.getText().toString();
        registerPass.getText().toString();
        registerPass2.getText().toString();

        //Oculta el teclado en pantalla
        InputMethodManager imm = (InputMethodManager) getSystemService(this.INPUT_METHOD_SERVICE);
        imm.toggleSoftInput(InputMethodManager.HIDE_IMPLICIT_ONLY, 0);


        //Condiciones para registro
        if (registerPass != registerPass2){

            validaEmail(registerMail.getText().toString());

            // recoge las variables de mail y contraseña y las pasa al metodo registrar
            String email = registerMail.getText().toString();
            String pass = registerPass.getText().toString();
            registrar(email, pass);

        }else{

            System.out.println("entra en else");
            System.out.println(registerPass);
            System.out.println(registerPass2);

            //borra las contraseñas
            registerPass.setText(""); registerPass2.setText("");

            //toast
            Context context = getApplicationContext();
            CharSequence text = "Las contraseñas no coinciden.";
            int duration = Toast.LENGTH_SHORT;

            Toast toast = Toast.makeText(context, text, duration);
            toast.show();

        }
    }

    private void registrar(String email, String pass){

        FirebaseAuth.getInstance().createUserWithEmailAndPassword(email, pass).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {

                if(task.isSuccessful()){
                    //toast
                    Context context = getApplicationContext();
                    CharSequence text = "Usuario creado correctamente";
                    int duration = Toast.LENGTH_SHORT;
                    Toast toast = Toast.makeText(context, text, duration);
                    toast.show();

                    //console
                    System.out.println("Usuario creado correctamente");

                }else{
                    //toast
                    Context context = getApplicationContext();
                    CharSequence text = "El usuario no se ha podido crear";
                    int duration = Toast.LENGTH_SHORT;
                    Toast toast = Toast.makeText(context, text, duration);
                    toast.show();

                    //console
                    System.out.println("El usuario no se ha podido crear");
                }
            }
        });
    }

    // metodo para validar emails.
    private static final String EMAIL_PATTERN = "^[a-zA-Z0-9#_~!$&'()*+,;=:.\"(),:;<>@\\[\\]\\\\]+@[a-zA-Z0-9-]+(\\.[a-zA-Z0-9-]+)*$";
    private Pattern pattern = Pattern.compile(EMAIL_PATTERN);
    private Matcher matcher;

    public boolean validaEmail(String email) {
        matcher = pattern.matcher(email);
        return matcher.matches();
    }
}
