package com.example.jesusf.proyectofinal;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class LoginActivity extends AppCompatActivity {


    private EditText nombreUsuario, userPass;
    private Button iniciarSesion;

    FirebaseAuth.AuthStateListener mAuthListener;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        getSupportActionBar().hide();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_login_activity);

        nombreUsuario = findViewById(R.id.txtuser);
        userPass = findViewById(R.id.txtpass);

        iniciarSesion = findViewById(R.id.button_inicio);

        mAuthListener = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                FirebaseUser user = firebaseAuth.getCurrentUser();
                if (user != null) {
                    System.out.println("Sesión iniciada con email: " + user.getEmail());
                } else {
                    System.out.println("Sesión cerrada");
                }
            }
        };

    }

    public void iniciarSesion(View v){
        String email = nombreUsuario.getText().toString();
        String pass = userPass.getText().toString();

        //Oculta el teclado en pantalla
        InputMethodManager imm = (InputMethodManager) getSystemService(this.INPUT_METHOD_SERVICE);
        imm.toggleSoftInput(InputMethodManager.HIDE_IMPLICIT_ONLY, 0);

        //firebase authentication
        FirebaseAuth.getInstance().signInWithEmailAndPassword(email, pass).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {

                if(task.isSuccessful()){

                    //toast
                    Context context = getApplicationContext();
                    CharSequence text = "La sesión se ha iniciado correctamente";
                    int duration = Toast.LENGTH_SHORT;

                    Toast toast = Toast.makeText(context, text, duration);
                    toast.show();

                    //console
                    System.out.println("La sesión se ha iniciado correctamente");

                }else{
                    //toast
                    Context context = getApplicationContext();
                    CharSequence text = "La sesión no se ha podido iniciar";
                    int duration = Toast.LENGTH_SHORT;

                    Toast toast = Toast.makeText(context, text, duration);
                    toast.show();

                    //console
                    System.out.println("La sesión no se ha podido iniciar");
                }
            }
        });
    }
}
