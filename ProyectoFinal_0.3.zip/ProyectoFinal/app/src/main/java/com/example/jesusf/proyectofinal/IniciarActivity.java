package com.example.jesusf.proyectofinal;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;

public class IniciarActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        getSupportActionBar().hide();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_iniciar_activity);
        
    }

    public void clickOnInicio(View view) {
        //Inicia Actividad LoginActivity
        Intent intent = new Intent(this, LoginActivity.class);
        startActivity(intent);
        }

    public void clickOnRegistro(View view) {
        //Inicia actividad RegistroActivity
        Intent intent = new Intent(this, RegistroActivity.class);
        startActivity(intent);
    }
}
